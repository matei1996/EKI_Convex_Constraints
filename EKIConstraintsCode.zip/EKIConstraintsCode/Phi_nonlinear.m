function [ phi ] = Phi_nonlinear( u,Gamma,G,y,beta,C_0)
    
    phi=(1/2)*norm((sqrtm(Gamma))\(G(u)-y))^2+(beta/2)*norm((sqrtm(C_0))\u)^2;
end

