function [dUdt]=ode_right_side_nonlin_CC(t,U,G,d,J,y,Gamma,beta,ubound,tau,C_0,v)

%Reshape into matrix form
U=reshape(U,[d,J]);
Y=repmat(y,1,J);

%Compute variables for ODE (RHS)
Gu=G(U);
Fu=[Gu;sqrt(beta)*U];
Fu_mean = mean(Fu,2);
U_mean = mean(U,2);
Gamma_reg = blkdiag(Gamma,C_0);
z=[Y;zeros(d,J)];

%Covariance matrix
C_uG = (1/(J-1))*(U-U_mean)*(Fu-Fu_mean)';
C_uu = (1/(J-1))*(U-U_mean)*(U-U_mean)';

%Choose level of variance inflation
%rho_t=1-1/(log(t+exp(1)));
%rho_t=0.8;
%EKI update formula
dUdt=-C_uG*(Gamma_reg\(Fu-z))+v(t)*C_uG*(Gamma_reg\(Fu-Fu_mean));

%Penalty nonlinear; explicit upper bound
penalty=(C_0\U_mean)/(0.5*norm((sqrtm(C_0))\U_mean)^2-ubound);

%Dynamics
dUdt=dUdt+(1/tau)*C_uu*penalty;

%Reshape matrix into vector form
dUdt=dUdt(:);

end



