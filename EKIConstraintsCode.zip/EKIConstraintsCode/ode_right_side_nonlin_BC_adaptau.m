function [dUdt]=ode_right_side_nonlin_BC_adaptau(t,U,G,d,J,y,Gamma,beta,Box,C_0,v)

%Reshape into matrix form
U=reshape(U,[d,J]);
Y=repmat(y,1,J);

%Compute variables for ODE (RHS)
Gu=G(U);
Fu=[Gu;sqrt(beta)*U];
Fu_mean = mean(Fu,2);
U_mean = mean(U,2);
Gamma_reg = blkdiag(Gamma,C_0);
z=[Y;zeros(d,J)];

%Adaptive penalty parameter
tau_update = 0.1*t+0.1;

%Covariance matrix
C_uG = (1/(J-1))*(U-U_mean)*(Fu-Fu_mean)';
C_uu = (1/(J-1))*(U-U_mean)*(U-U_mean)';


%Choose level of variance inflation
%rho_t=1-1/(log(t+exp(1)));
%rho_t=0.8;

%EKI update
dUdt=-C_uG*(Gamma_reg\(Fu-z))+v(t)*C_uG*(Gamma_reg\(Fu-Fu_mean));

%Penalty Term
penalty=-1./(Box(1)-U_mean)+1./(U_mean-Box(2));

%Dynamics
dUdt=dUdt+(1/tau_update)*C_uu*penalty;

%Reshape matrix into vector form
dUdt=dUdt(:);

end



