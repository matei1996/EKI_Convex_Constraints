
% Script to initalize all initial parameters

I = 7; % discretization of the PDE
F = 10*ones(I-1,I-1); % RHS

% grid for plotting
s1=linspace(0,1,I-1);
s2=linspace(0,1,I-1);
[S1,S2]= meshgrid(s1,s2);

% parameters of covariance matrix for gaussian random field
% we work directly in KL expansion
tau_ini = 0.01;
alpha = 2;
meanfield = 0;

I_c = 3^2; % number of coefficients for KL expansion
C0 = eye(I_c,I_c);

% compute KL expansion of the gaussian random field
u_kle = @(xi)kle_execute(xi,S1,S2,meanfield,alpha,tau_ini);

% compute truth vector
coef_true = mvnrnd(zeros(I_c,1),C0,1)';
utrue = u_kle(coef_true);

U = reshape(utrue,[I-1 I-1]); %for plotting purposes

%Define levels of variance inflation
h_1= @(t)0.8;
h_2= @(t)1-1/(log(t+exp(1)));

% reference solution
G_solve = @(utr) G_darcy(utr,I-1,F);
y_solution = G_solve(utrue);


% Construction of Observation matrix O
Points = 1:length(y_solution);
K = 30; %amount of observation points
O = zeros(K,length(y_solution));

for i = 1:K
     obs_point = randi([1 length(Points)],1,1);
    O(i,Points(obs_point)) = 1;
    Points(obs_point) = [];
end


%%define forward model
G = @(utr) O*G_darcy(utr,I-1,F);

%%compute noisefree observation
y = G(utrue);

%%perturb by some noise
Gamma = 0.01*eye(K,K);
y_noise = y+Gamma^(1/2)*randn(K,1);


%parameters of EKI Model

d=size(utrue,1); %dimension of parameter space
k=K; %dimension of observation space
J=10; %ensemble size
beta=1e-2; %regularisation factor
T=1e5; %End time
C_0=eye(d); %Scaling Regularization matrix
y=y_noise;
tau_adap=0.1; %penalty parameter

%Box Constraints
a = min(utrue)+0.3*abs(min(utrue)); %lower bound
b = max(utrue)-0.3*abs(max(utrue)); %upper bound

%Generate initial ensemble Initial 
coef_0 = mvnrnd(zeros(I_c,1),C0,J)';
u_0 = u_kle(coef_0); 

%Generate Box for parameters
Box = [a,b];
LB = Box(1)*ones(d,1);
UB = Box(2)*ones(d,1);

u_1 = u_0; %Copy of initial ensemble; project Initial ensemble into Box
epsilon=1e-2;
u_1(u_1<=Box(1)) = Box(1)+epsilon;
u_1(u_1>=Box(2)) = Box(2)-epsilon;

%Set evaluation times for ODE solver
tspan_1=0:0.02:1;
tspan_2= 1:T/100:T;
tspan_1(end)=[];
tspan_alt=[tspan_1,tspan_2];
t=zeros(length(tspan_alt),1);
opts=odeset('RelTol',1e-8,'AbsTol',1e-8);

%Decide, for how many penalty parameters we want to compute the error
diff_t=log10(T)+1;

L=length(tspan_alt); %Variable for evaluation at the end

%Preallocate vectors for results for Constraints
est_err_BC=zeros(length(tspan_alt),diff_t+1);
est_err_sol_BC=zeros(length(tspan_alt),diff_t+1);
est_err_BC_b=zeros(length(tspan_alt),diff_t+1);
est_err_sol_BC_b=zeros(length(tspan_alt),diff_t+1);

%Preallocation of different error values computed
est_err=zeros(length(tspan_alt),1);
est_err_sol=zeros(length(tspan_alt),1);
est_err_b=zeros(length(tspan_alt),diff_t+1);
est_err_sol_b=zeros(length(tspan_alt),diff_t+1);

%Compute variables for subspace property

u_1_bar=mean(u_1,2);
e_0=u_1-u_1_bar; %centered particles
[R,basiccol]=rref(e_0); %determine linear independent ensembles
if J<=d
    E_0=e_0;
else
    E_0=e_0(:,basiccol);
end

%Projection onto subspace; needed for optimisation
P_E=E_0*((E_0'*E_0)\(E_0'));
u_sub_orth=u_1_bar-P_E*u_1_bar;

end_solution_eki=u_1;

filename="EKI_Darcy_nonlin_adap_tau_params.mat";
save(filename);