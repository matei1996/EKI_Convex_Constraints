%Code for EKI with convex constraints


clearvars;

%Variable 'nonlin' is either 0,1,2, depending on which experiment is to be
%conducted. 0=Pseudolinear, 1=Nonlinear with fixed tau, 2=Nonlinear with
%adaptive tau
nonlin=1;


%For plots
col = {[0 0 255]./255,[200 200 255]./255,[170 170 255]./255,[150 150 255]./255,[100 100 255]./255};
linest = {'-','-.','--',':'};

%-------------------------------------------

%-------------------------------------------
% Initialiazation of nonlinear example
%!!! Script 'gen_EKI_darcy_nonlin_fixtau_params.m' needs to be executed first!!!
if nonlin==true

%Load initial parameters
load('EKI_Darcy_nonlin_fix_tau_params.mat');

%Optimisation of initial potential


fun = @(u) Phi_nonlinear(u,Gamma,G,y,beta,C_0);
options = optimoptions(@fmincon,'MaxFunctionEvaluations',10^8,'Algorithm','sqp','MaxIterations',200,'Display','iter','OptimalityTolerance',10^(-10),'StepTolerance',10^(-15));


%Solve EKI
tic;
[t_long,U_long]=ode45(@(t,U) ode_right_side_nonlin(t,U,G,d,J,y,Gamma,beta,1,C_0),tspan_alt,u_1(:),opts);
U_long=reshape(U_long.',d,J,[]);
fprintf(' EKI: ')
toc;

%Solve adapted EKI for Constraints with fixed variance inflation
tic;
[t_BC,U_long_BC]=ode45(@(t,U) ode_right_side_nonlin_BC(t,U,G,d,J,y,Gamma,beta,Box,tau_adap,C_0,h_1),tspan_alt,u_1(:),opts);
U_long_BC=reshape(U_long_BC.',d,J,[]);
fprintf(' EKI with BC: ')
toc;

%Define function for optimisation of Phi_b
%Use computed value of adapted EKI as initial value of optimisation
%end_solution_eki=U_long_BC(:,:,end);
end_solution_eki=u_1;
fun_b = @(u) Phi_nonlinear_b(u,Gamma,G,y,a,b,beta,C_0,tau_adap);


%Subspace property has to be considered if J<=d
if J<=d
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,LB,UB,[],options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fmincon(fun_b,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options);

else
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],[],[],LB,UB,[],options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fminunc(fun_b,mean(end_solution_eki,2),options);

end



    %Evaluate results
    for m=1:L    
         est_err_BC(m) = norm(fun(mean(U_long_BC(:,:,m),2))-fval);
         est_err_sol_BC(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit);
         est_err_BC_b(m) = norm(fun_b(mean(U_long_BC(:,:,m),2))-fval_b);
         est_err_sol_BC_b(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit_b);
         est_err(m) = norm(fun(mean(U_long(:,:,m),2))-fval);
         est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);
         est_err_b(m) = norm(fun(mean(U_long(:,:,m),2))-fval_b);
         est_err_sol_b(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit_b);             
    end

est_err_BC_b_constantvi=est_err_BC_b;
est_err_sol_BC_b_constantvi=est_err_sol_BC_b;

%Plot computed solution
res_end_mean=mean(U_long(:,:,end),2);
res_end_mean_BC=mean(U_long_BC(:,:,end),2);

U_cvi = reshape(res_end_mean,[I-1 I-1]);
%U_ref = reshape(reg_data_missfit,[I-1 I-1]);
U_ref_b_cvi =reshape(reg_data_missfit_b,[I-1 I-1]);
U_BC_cvi = reshape(res_end_mean_BC,[I-1 I-1]);


%Plot Box constraints
u=linspace(0,32,81);
v=linspace(0,32,81);
[x_gr,y_gr]=meshgrid(u,v);
z2=0*x_gr + Box(1);    % the 0*x + exp(1) makes sure the output for z2 is the same size
z3=0*x_gr + Box(2);    % as x and y, but only has the value of e in each component.

fig1 = figure(1);    
clf(fig1)
set(fig1, 'Units', 'normalized', 'Position', [0.1, 0.5, 0.4, 0.4]);

% plot the true parameter„
ax1=subplot(2,2,1);
surf(reshape(utrue,I-1,I-1),'edgecolor','none');hold on
mesh(x_gr,y_gr,z2,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5); hold on
mesh(x_gr,y_gr,z3,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5);
title('utruth','FontSize',15)
% plot the EnKF estimates in the parameter space
figure(1)
ax2=subplot(2,2,2);
surf(U_ref_b_cvi,'edgecolor','none');hold on
mesh(x_gr,y_gr,z2,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5); hold on
mesh(x_gr,y_gr,z3,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5);
title('Optimiser solution','FontSize',15)
ax3=subplot(2,2,3);
surf(U_cvi,'edgecolor','none');hold on
mesh(x_gr,y_gr,z2,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5); hold on
mesh(x_gr,y_gr,z3,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5);
title('EKI','FontSize',15)
ax4=subplot(2,2,4);
surf(U_BC_cvi,'edgecolor','none');hold on
mesh(x_gr,y_gr,z2,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5); hold on
mesh(x_gr,y_gr,z3,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5);
title('EKI with BC','FontSize',15)

%Solve adapted EKI for Constraints with increasing variance inflation
tic;
[t_BC,U_long_BC]=ode45(@(t,U) ode_right_side_nonlin_BC(t,U,G,d,J,y,Gamma,beta,Box,tau_adap,C_0,h_2),tspan_alt,u_1(:),opts);
U_long_BC=reshape(U_long_BC.',d,J,[]);
fprintf(' EKI with BC: ')
toc;

%Use computed value of adapted EKI as initial value of optimisation
%end_solution_eki=U_long_BC(:,:,end);
end_solution_eki=u_1;

%Subspace property has to be considered if J<=d
if J<=d
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,LB,UB,[],options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fmincon(fun_b,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options);

else
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],[],[],LB,UB,[],options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fminunc(fun_b,mean(end_solution_eki,2),options);

end

    %Evaluate results
    for m=1:L    
         est_err_BC(m) = norm(fun(mean(U_long_BC(:,:,m),2))-fval);
         est_err_sol_BC(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit);
         est_err_BC_b(m) = norm(fun_b(mean(U_long_BC(:,:,m),2))-fval_b);
         est_err_sol_BC_b(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit_b);
         est_err(m) = norm(fun(mean(U_long(:,:,m),2))-fval);
         est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);
         %est_err_b(m) = norm(fun(mean(U_long(:,:,m),2))-fval_b);
         %est_err_sol_b(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit_b);             
    end

%Evaluate solution
est_err_BC_b_vi=est_err_BC_b;
est_err_sol_BC_b_vi=est_err_sol_BC_b;

%Solution at the end
res_end_mean=mean(U_long(:,:,end),2);
res_end_mean_BC=mean(U_long_BC(:,:,end),2);

U_vi = reshape(res_end_mean,[I-1 I-1]);
%U_ref = reshape(reg_data_missfit,[I-1 I-1]);
U_ref_b_vi =reshape(reg_data_missfit_b,[I-1 I-1]);
U_BC_vi = reshape(res_end_mean_BC,[I-1 I-1]);

%To plot Box constraints
u=linspace(0,32,81);
v=linspace(0,32,81);
[x_gr,y_gr]=meshgrid(u,v);
z2=0*x_gr + Box(1);    % the 0*x + exp(1) makes sure the output for z2 is the same size
z3=0*x_gr + Box(2);    % as x and y, but only has the value of e in each component.

fig2 = figure(2);    
clf(fig2)
set(fig2, 'Units', 'normalized', 'Position', [0.1, 0.5, 0.4, 0.4]);

% plot the true parameter„
ax1=subplot(2,2,1);
surf(reshape(utrue,I-1,I-1),'edgecolor','none');hold on
mesh(x_gr,y_gr,z2,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5); hold on
mesh(x_gr,y_gr,z3,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5);
title('utruth','FontSize',15)
% plot the EnKF estimates in the parameter space
figure(2)
ax2=subplot(2,2,2);
surf(U_ref_b_vi,'edgecolor','none');hold on
mesh(x_gr,y_gr,z2,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5); hold on
mesh(x_gr,y_gr,z3,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5);
title('Optimiser solution','FontSize',15)
ax3=subplot(2,2,3);
surf(U_vi,'edgecolor','none');hold on
mesh(x_gr,y_gr,z2,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5); hold on
mesh(x_gr,y_gr,z3,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5);
title('EKI','FontSize',15)
ax4=subplot(2,2,4);
surf(U_BC_vi,'edgecolor','none');hold on
mesh(x_gr,y_gr,z2,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5); hold on
mesh(x_gr,y_gr,z3,'EdgeColor','none', 'FaceColor', [128,128,128]./255,'FaceAlpha',0.5);
title('EKI with BC','FontSize',15)

%Plot errors
fig24 = figure(24);
clf(24);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err_b,'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2.5) 
plot(tspan_alt,est_err_BC_b_constantvi,'Color',[0.4660 0.6740 0.1880],'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_BC_b_vi,'Color',[0 0.4470 0.7410],'Linestyle',linest(3),'LineWidth',2.5)
lgd_obs = legend({'EKI','EKI with CC ($\rho_t=0.8$)','EKI with CC ($\rho_t=1-\frac{1}{log(t+exp(1))}$)'},'interpreter', 'latex','Location','southwest','FontSize',12);
title(lgd_obs,'$||\Phi^b(\bar{u}(t))-\Phi^b(u_{\ast}^{\tau})||$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Absolute error of functionals', 'interpreter', 'latex','FontSize',20)

fig25 = figure(25);
clf(25);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err_sol_b,'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC_b_constantvi,'Color',[0.4660 0.6740 0.1880],'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC_b_vi,'Color',[0 0.4470 0.7410],'Linestyle',linest(3),'LineWidth',2)
lgd = legend({'EKI','EKI with CC ($\rho_t=0.8$)','EKI with CC ($\rho_t=1-\frac{1}{log(t+exp(1))}$)'},'interpreter', 'latex','Location','southwest','FontSize',12);
title(lgd,'$||\bar{u}(t)-u_{\ast}^{\tau}||$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Absolute error of computed solutions','interpreter', 'latex','FontSize',20)


elseif nonlin==false 
%Load initial parameters for Pseudolinear example
%!!! Script 'gen_EKI_Heat_psylin_fixtau_params.m' needs to be executed first!!!
load('EKI_Heat_psylin_fix_tau_params.mat');

%Set evaluation times for ODE solver
tspan_1=0:0.02:1;
tspan_2= 1:T/100:T;
tspan_1(end)=[];
tspan_alt=[tspan_1,tspan_2];
t=zeros(length(tspan_alt),1);
opts=odeset('RelTol',1e-8,'AbsTol',1e-8);


L=length(tspan_alt); %Variable for evaluation at the end

%Preallocate vectors for results for Constraints
est_err_BC=zeros(length(tspan_alt),1);
est_err_sol_BC=zeros(length(tspan_alt),1);
est_err_BC_b=zeros(length(tspan_alt),1);
est_err_sol_BC_b=zeros(length(tspan_alt),1);
%Preallocation of different error values computed

est_err=zeros(length(tspan_alt),1);
est_err_sol=zeros(length(tspan_alt),1);
est_err_b=zeros(length(tspan_alt),1);
est_err_sol_b=zeros(length(tspan_alt),1);

%Preallocation of norm of vectors error values computed
norm_eki=zeros(length(tspan_alt),1);
norm_eki_bounded=zeros(length(tspan_alt),1);

%Vectors for Ensemble collapse
est_err_ek = zeros(length(tspan_alt),J);
est_err_ek_BC = zeros(length(tspan_alt),J);

%Optimisation of initial potential

fun = @(u) Phi_nonlinear(u,Gamma,G,y,a,b,beta,C_0,1);
options = optimoptions(@fmincon,'MaxFunctionEvaluations',10^8,'Algorithm','sqp','MaxIterations',200,'Display','iter','OptimalityTolerance',10^(-10),'StepTolerance',10^(-15));

%Nonlinear constrains
fun_b = @(u) Phi_nonlinear_conv(u,Gamma,G,y,ubound,beta,C_0,tau_adap);

%Function for nonlinconstrains
c = @(u)0.5*norm((sqrtm(C_0))\u)^2-ubound;
ceq = @(u)[];
cons = @(x)deal(c(x),ceq(x));

%Solve EKI
tic;
[t_long,U_long]=ode45(@(t,U) ode_right_side_nonlin(t,U,G,d,J,y,Gamma,beta,1,C_0),tspan_alt,u_1(:),opts);
U_long=reshape(U_long.',d,J,[]);
fprintf(' EKI: ')
toc;

%Solve adapted EKI for Constraints with constant vi
tic;
[t_BC,U_long_BC]=ode45(@(t,U) ode_right_side_nonlin_CC(t,U,G,d,J,y,Gamma,beta,ubound,tau_adap,C_0,h_1),tspan_alt,u_1(:),opts);
U_long_BC=reshape(U_long_BC.',d,J,[]);
fprintf(' EKI with CC: ')
toc;


end_solution_eki=u_1;


%Subspace property has to be considered if J<=d
if J<=d
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],cons,options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fmincon(fun_b,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options);

else
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],[],[],[],[],cons,options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fminunc(fun_b,mean(end_solution_eki,2),options);

end

    %Evaluate results
    for m=1:L  
         est_err_BC(m) = norm(fun(mean(U_long_BC(:,:,m),2))-fval);
         est_err_sol_BC(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit);
         est_err_BC_b(m) = norm(fun_b(mean(U_long_BC(:,:,m),2))-fval_b);
         est_err_sol_BC_b(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit_b);
         est_err(m) = norm(fun(mean(U_long(:,:,m),2))-fval);
         est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);
         est_err_b(m) = norm(fun(mean(U_long(:,:,m),2))-fval_b);
         est_err_sol_b(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit_b);
         norm_eki_bounded(m)=0.5*norm(sqrtm(C_0)\mean(U_long_BC(:,:,m),2))^2;

     for j=1:J
         est_err_ek(m,j)=norm(U_long(:,j,m)-mean(U_long(:,:,m),2));
         est_err_ek_BC(m,j)=norm(U_long_BC(:,j,m)-mean(U_long_BC(:,:,m),2));
     end

    end

%Evaluate solution
est_err_BC_b_constantvi=est_err_BC_b;
est_err_sol_BC_b_constantvi=est_err_sol_BC_b;
ek_eki=mean(est_err_ek,2);
ek_eki_BC_constantvi=mean(est_err_ek_BC,2);
%norm_eki_constantvi=norm_eki;
norm_eki_bounded_constantvi=norm_eki_bounded;

%Solve adapted EKI for Constraints with adaptive vi
tic;
[t_BC,U_long_BC]=ode45(@(t,U) ode_right_side_nonlin_CC(t,U,G,d,J,y,Gamma,beta,ubound,tau_adap,C_0,h_2),tspan_alt,u_1(:),opts);
U_long_BC=reshape(U_long_BC.',d,J,[]);
fprintf(' EKI with CC: ')
toc;

end_solution_eki=u_1;


%Subspace property has to be considered if J<=d
if J<=d
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],cons,options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fmincon(fun_b,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options);

else
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],[],[],[],[],cons,options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fminunc(fun_b,mean(end_solution_eki,2),options);

end

    %Evaluate results
    for m=1:L  
         est_err_BC(m) = norm(fun(mean(U_long_BC(:,:,m),2))-fval);
         est_err_sol_BC(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit);
         est_err_BC_b(m) = norm(fun_b(mean(U_long_BC(:,:,m),2))-fval_b);
         est_err_sol_BC_b(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit_b);
         est_err(m) = norm(fun(mean(U_long(:,:,m),2))-fval);
         est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);
         est_err_b(m) = norm(fun(mean(U_long(:,:,m),2))-fval_b);
         est_err_sol_b(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit_b);
         norm_eki(m)=0.5*norm(sqrtm(C_0)\mean(U_long(:,:,m),2))^2;
         norm_eki_bounded(m)=0.5*norm(sqrtm(C_0)\mean(U_long_BC(:,:,m),2))^2;

     for j=1:J
         est_err_ek(m,j)=norm(U_long(:,j,m)-mean(U_long(:,:,m),2));
         est_err_ek_BC(m,j)=norm(U_long_BC(:,j,m)-mean(U_long_BC(:,:,m),2));
     end

    end

%Computed solutions at the end
res_end_mean=mean(U_long(:,:,end),2);
res_end_mean_BC=mean(U_long_BC(:,:,end),2);

est_err_BC_b_vi=est_err_BC_b;
est_err_sol_BC_b_vi=est_err_sol_BC_b;
ek_eki_BC_vi=mean(est_err_ek_BC,2);
norm_eki_vi=norm_eki;
norm_eki_bounded_vi=norm_eki_bounded;

%Plot results
%Plot ensemble collapse
fig6 = figure(6);
clf(6);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,0.5*mean(ek_eki.^2,2),'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2)
plot(tspan_alt,0.5*mean(ek_eki_BC_constantvi.^2,2),'Color',[0.4660 0.6740 0.1880],'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,0.5*mean(ek_eki_BC_vi.^2,2),'Color',[0 0.4470 0.7410],'Linestyle',linest(3),'LineWidth',2.5)
plot(tspan_alt,tspan_alt.^(-1),'Color',[0 0 0],'Linestyle',linest(4),'LineWidth',2.5)
lgd_ek = legend({'EKI','EKI with CC ($\rho_t=0.8$)','EKI with CC ($\rho_t=1-\frac{1}{log(t+exp(1))}$)','$t^{-1}$'},'interpreter', 'latex','Location','southwest','FontSize',12);
title(lgd_ek,'$V_e(t)$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Ensemble Collapse','interpreter', 'latex','FontSize',20)

%Plot errors
fig24 = figure(24);
clf(24);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err_b,'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2.5) 
plot(tspan_alt,est_err_BC_b_constantvi,'Color',[0.4660 0.6740 0.1880],'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_BC_b_vi,'Color',[0 0.4470 0.7410],'Linestyle',linest(3),'LineWidth',2.5)
lgd_obs = legend({'EKI','EKI with CC ($\rho_t=0.8$)','EKI with CC ($\rho_t=1-\frac{1}{log(t+exp(1))}$)'},'interpreter', 'latex','Location','southwest','FontSize',12);
title(lgd_obs,'$||\Phi^b(\bar{u}(t))-\Phi^b(u_{\ast}^{\tau})||$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Absolute error of functionals', 'interpreter', 'latex','FontSize',20)

fig25 = figure(25);
clf(25);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err_sol_b,'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC_b_constantvi,'Color',[0.4660 0.6740 0.1880],'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC_b_vi,'Color',[0 0.4470 0.7410],'Linestyle',linest(3),'LineWidth',2)
lgd = legend({'EKI','EKI with CC ($\rho_t=0.8$)','EKI with CC ($\rho_t=1-\frac{1}{log(t+exp(1))}$)'},'interpreter', 'latex','Location','southwest','FontSize',12);
title(lgd,'$||\bar{u}(t)-u_{\ast}^{\tau}||$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Absolute error of computed solutions','interpreter', 'latex','FontSize',20)

%Plot estimated solutions
fig10 = figure(10);
clf(10);
hold on
grid on
plot(x,res_end_mean,'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2)
plot(x,res_end_mean_BC,'Color',[0 0.4470 0.7410],'Linestyle',linest(2),'LineWidth',2.5)
plot(x,reg_data_missfit_b,'Color',[0.4660 0.6740 0.1880],'Linestyle',linest(3),'LineWidth',2.5)
plot(x,utrue,'Color',[0 0 0],'Linestyle',linest(4),'LineWidth',2.5)
legend({'EKI','EKI with CC $(\rho_t=0.8)$','Reference solution','utrue'},'interpreter', 'latex','Location','northwest','FontSize',15);
xlabel('T')
title('Computed solutions', 'interpreter', 'latex','FontSize',20)

%Plot norm of solutions and upper bound
fig11 = figure(11);
clf(11);
hold on
grid on
set(gca, 'XScale', 'log')
plot(tspan_alt,norm_eki,'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2)
plot(tspan_alt,norm_eki_bounded_constantvi,'Color',[0.4660 0.6740 0.1880],'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,norm_eki_bounded_vi,'Color',[0 0.4470 0.7410],'Linestyle',linest(3),'LineWidth',2.5)
plot(tspan_alt,zeros(L,1)+ubound,'Color',[0 0 0],'Linestyle',linest(4),'Linewidth',2.5)
lgd_sol=legend({'EKI','EKI with CC ($\rho_t=0.8$)','EKI with CC ($\rho_t=1-\frac{1}{log(t+exp(1))}$)','Upper Bound'},'interpreter', 'latex','Location','northwest','Fontsize',12);
title(lgd_sol,'$\frac{1}{2}\|\bar{u}_t\|^2_{C(s,t)}$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Norm of computed solutions', 'interpreter', 'latex','FontSize',20)  


%Initialization of example with adaptive penalty parameter
%-------------------------------------------------
elseif nonlin==2
%!!! Script 'gen_EKI_Darcy_nonlin_adaptau_params.m' needs to be executed first!!!

load('EKI_Darcy_nonlin_adap_tau_params.mat');

%Run for different values of tau
for counter=1:diff_t 
%Optimisation of initial potential

fun = @(u) Phi_nonlinear(u,Gamma,G,y,a,b,beta,C_0,1);
options = optimoptions(@fmincon,'MaxFunctionEvaluations',10^8,'Algorithm','sqp','MaxIterations',200,'Display','iter','OptimalityTolerance',10^(-10),'StepTolerance',10^(-15));

%Solve EKI
tic;
[t_long,U_long]=ode45(@(t,U) ode_right_side_nonlin(t,U,G,d,J,y,Gamma,beta,1,C_0),tspan_alt,u_1(:),opts);
U_long=reshape(U_long.',d,J,[]);
fprintf(' EKI: ')
toc;

%Solve adapted EKI for Constraints
tic;
[t_BC,U_long_BC]=ode45(@(t,U) ode_right_side_nonlin_BC(t,U,G,d,J,y,Gamma,beta,Box,tau_adap,C_0,h_1),tspan_alt,u_1(:),opts);
U_long_BC=reshape(U_long_BC.',d,J,[]);
fprintf(' EKI with BC: ')
toc;

%Define function for optimisation of Phi_b
%Use computed value of adapted EKI as initial value of optimisation
%end_solution_eki=U_long_BC(:,:,end);
end_solution_eki=u_1;
fun_b = @(u) Phi_nonlinear_b(u,Gamma,G,y,a,b,beta,C_0,tau_adap);


%Subspace property has to be considered if J<=d
if J<=d
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,LB,UB,[],options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fmincon(fun_b,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options);

else
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],[],[],LB,UB,[],options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fminunc(fun_b,mean(end_solution_eki,2),options);

end


    %Evaluate results
    for m=1:L    
         est_err_BC(m,counter) = norm(fun(mean(U_long_BC(:,:,m),2))-fval);
         est_err_sol_BC(m,counter)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit);
         est_err_BC_b(m,counter) = norm(fun_b(mean(U_long_BC(:,:,m),2))-fval_b);
         est_err_sol_BC_b(m,counter)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit_b);
         est_err(m) = norm(fun(mean(U_long(:,:,m),2))-fval);
         est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);
         est_err_b(m,counter) = norm(fun(mean(U_long(:,:,m),2))-fval_b);
         est_err_sol_b(m,counter)=norm(mean(U_long(:,:,m),2)-reg_data_missfit_b);             
    end

%end_solution_eki=u_1; %use same initial ensemble every time
tau_adap=tau_adap*10; %adapt penalty parameter
end

% Last run with adaptive tau

tic;
%Box constrains
[t_BC,U_long_BC]=ode45(@(t,U) ode_right_side_nonlin_BC_adaptau(t,U,G,d,J,y,Gamma,beta,Box,C_0,h_1),tspan_alt,u_1(:),opts);
U_long_BC=reshape(U_long_BC.',d,J,[]);
fprintf(' EKI with BC: ')
toc;

end_solution_eki=U_long_BC(:,:,end);

%Set tau to highest value
tau_adap=1e4;

%Define Phi_b
fun_b = @(u) Phi_nonlinear_b(u,Gamma,G,y,a,b,beta,C_0,tau_adap);

%Subspace property has to be considered if J<=d
if J<=d
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,LB,UB,[],options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fmincon(fun_b,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options);

else
    %Optimise with respect to Phi
    [reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],[],[],LB,UB,[],options);
    %Optimise with respect to Phi_b
    [reg_data_missfit_b,fval_b] = fminunc(fun_b,mean(end_solution_eki,2),options);

end

      for m=1:L
          est_err(m) = norm(fun(mean(U_long(:,:,m),2))-fval);
          est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);
          est_err_b(m,counter+1) = norm(fun(mean(U_long(:,:,m),2))-fval_b);
          est_err_sol_b(m,counter+1)=norm(mean(U_long(:,:,m),2)-reg_data_missfit_b);        
          est_err_BC(m,counter+1) = norm(fun(mean(U_long_BC(:,:,m),2))-fval);
          est_err_sol_BC(m,counter+1)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit);
          est_err_BC_b(m,counter+1) = norm(fun_b(mean(U_long_BC(:,:,m),2))-fval_b);
          est_err_sol_BC_b(m,counter+1)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit_b);
      end

%Plot results
fig4 = figure(4);
clf(4);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err,'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2)
plot(tspan_alt,est_err_BC(:,2),'Color',[200 200 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_BC(:,3),'Color',[170 170 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_BC(:,4),'Color',[130 130 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_BC(:,5),'Color',[100 100 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_BC(:,6),'Color',[0 0 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_BC(:,7),'Color',[0 130 0]./255,'Linestyle',linest(3),'LineWidth',2.5)
lgd_obs = legend({'EKI','EKI with BC $(\tau=1)$','EKI with BC $(\tau=10)$','EKI with BC $(\tau=100)$','EKI with BC $(\tau=1000)$','EKI with BC $(\tau=10000)$','Adaptive $\tau$'},'interpreter', 'latex','Location','southwest','FontSize',10);
title(lgd_obs,'$||\Phi^{reg}(\bar{u}(t))-\Phi^{reg}(u_{\ast})||$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Absolute error of functionals', 'interpreter', 'latex','FontSize',20)

fig5 = figure(5);
clf(5);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err_sol,'Color',[204 37 41]./255,'Linestyle',linest(1),'LineWidth',2)
plot(tspan_alt,est_err_sol_BC(:,2),'Color',[200 200 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC(:,3),'Color',[170 170 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC(:,4),'Color',[130 130 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC(:,5),'Color',[100 100 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC(:,6),'Color',[0 0 255]./255,'Linestyle',linest(2),'LineWidth',2.5)
plot(tspan_alt,est_err_sol_BC(:,7),'Color',[0 130 0]./255,'Linestyle',linest(3),'LineWidth',2.5)
lgd= legend({'EKI','EKI with BC $(\tau=1)$','EKI with BC $(\tau=10)$','EKI with BC $(\tau=100)$','EKI with BC $(\tau=1000)$','EKI with BC $(\tau=10000)$','Adaptive $\tau$'},'interpreter', 'latex','Location','southwest','FontSize',10);
title(lgd,'$||\bar{u}(t)-u_{\ast}||$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Absolute error of computed solutions','interpreter', 'latex','FontSize',20)

end

%---------------------------------------------------------------
%The Code below is for saving results and loading for different levels of
%variance inflation; needs to be adapted accordingly

%!!!!!!You need to run the code above with different levels of variance
%inflation to plot the results!!!!!!!!

%Take the mean ensemble collapse over all runs
%ek_eki=est_err_ek;
%ek_eki_BC=est_err_ek_BC;

%Fixed tau one run
% filename="results_nlin_cvi_different_runs_tau.mat";
% save(filename,"u_0","utrue","y_noise","G","Box","C_0","ek_eki","ek_eki_BC","est_err_b","est_err_BC_b","est_err_sol_b","est_err_sol_BC_b","fval_b","Gamma","reg_data_missfit_b","t_BC","t_long","tspan_alt","U_long","U_long_BC","norm_eki","norm_eki_bounded");
% filename_full="resultsnlin_cvi_different_runs_tau_full.mat";
% save(filename_full);

%Adaptive tau multiple runs
%filename="results_nlin_cvi_adaptive_tau.mat";
%save(filename,"u_0","utrue","y_noise","G","Box","C_0","est_err","est_err_sol","est_err_b","est_err_sol_b","est_err_BC_b","est_err_sol_BC_b","est_err_BC","est_err_sol_BC");
%filename_full="resultsnlin_cvi_adaptive_tau_full.mat";
%save(filename_full);

%load("results_nlin_cvi_adaptive_tau.mat")

% % Plot results to compare different levels of variance inflation
% load("results_cons_vi_psylinear_full.mat","reg_data_missfit_b","res_end_mean","res_end_mean_BC","x","utrue","est_err","est_err_sol");
% load("results_cons_vi_psylinear_full.mat","ek_eki","ek_eki_BC","norm_eki","norm_eki_bounded","ubound");
% load("results_cons_vi_psylinear.mat","est_err_BC_b","est_err_sol_BC_b");
% est_err_BC_constantvi=est_err_BC_b;
% est_err_sol_BC_constantvi=est_err_sol_BC_b;
% ek_eki_constantvi=ek_eki;
% ek_eki_BC_constantvi=ek_eki_BC;
% norm_eki_constantvi=norm_eki;
% norm_eki_bounded_constantvi=norm_eki_bounded;
% 
% load("results_vi_psylinear_full.mat","ek_eki","ek_eki_BC","norm_eki","norm_eki_bounded");
% load("results_vi_psylinear.mat","est_err_BC_b","est_err_sol_BC_b");
% est_err_BC_vi=est_err_BC_b;
% est_err_sol_BC_vi=est_err_sol_BC_b;
% ek_eki_vi=ek_eki;
% ek_eki_BC_vi=ek_eki_BC;
% norm_eki_vi=norm_eki;
% norm_eki_bounded_vi=norm_eki_bounded;

%load("results_nvi.mat","est_err_BC_b","est_err_sol_BC_b");
%est_err_BC_nvi=est_err_BC_b;
%est_err_sol_BC_nvi=est_err_sol_BC_b;

%file2 = sprintf('comp_sol_2d_psylinear_bc_cons_vi.eps');
%print('-depsc',file2)



