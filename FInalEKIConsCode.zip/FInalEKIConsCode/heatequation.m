function u = heatequation(u_0,T,h,dt,plot_results, f)
% Solve Heat equation in 1D 

%                 u_t = u_xx + f   (t > 0, 0 < x < 1)
%            u(t=0,x) = u_0        (0 < x < 1)
%   u(t,x=0),u(t,x=1) = 0          (t>=0)

% up to time T, using the Crank-Nicolson Method with time step size dt and
% finite differences stepsize h

% h:     spatial stepsize (scalar)
% dt:    time stepsize (scalar)
% u_0:   initial vector ((1/h -1)x1 vector)
% T:     end time (scalar)
% f:     forcing ((1/h -1)x1 vector) (optional; default f = 0)



% Note that this code currently only supports the case where T/dt yields
% an integer value.

time_steps = int32(T/dt);

N  = (1/h) -1; %(Number of discretisation points)
x = h:h:(1-h); % Interior points, note that the boundary condition implies
               % u = 0 at the boundary

if ~exist('f')
   f = zeros(1,N);
end

u = zeros(time_steps, N);
u(1,:) = u_0;

e = ones(N,1);
Lap_mat = (1/h^2)*spdiags([e -2*e e],-1:1,N,N);

for i = 1:time_steps
    %u(i+1,:)  = ((speye(N) -(dt/2)*Lap_mat)\( u(i,:) + dt*f' + (dt/2)*del2(u(i,:),h))')' ;
    u(i+1,:)  = ((speye(N) -(dt/2)*Lap_mat)\( dt*f' + (dt/2)*(Lap_mat*u(i,:)')')')' ;
end

if plot_results
    subplot(2,2,[1 2])
   imagesc(0:dt:T-dt, x, u')
    title('Heat Equation: u_t = u_{xx} + f')
    xlabel('time t')
    ylabel('space x') 
    subplot(2,2,3)
    plot(x,u_0)
    title('Initial condition')
    ylabel('space x') 
    subplot(2,2,4)
    plot(x,f)
    title('Forcing')
    ylabel('space x') 
    
end


end

