%Apply EKI/Subsampling for nonlinear 2D-darcy flow;
%we consider here EKI for the parameters


clearvars;

nonlin=1;

% Fixed paramters for heat equation code
% timestepping/finite differences parameters

%!!! Script 'gen_nonlin_darcy_params.m' needs to be executed first!!!

% Load parameters for Darcy Flow and for initialisation of the EKI
% load('EKI_Darcy_nonlin_params.mat');

%Script to solve 2D nonlinear darcy problem in the coefficients
%as well as to initialize EKI/Subsampling


%-------------------------------------------

%-------------------------------------------
% Initialiazation of nonlinear example

if nonlin==true
% Initialize all starting values

% discretization of the PDE
I = 2^5+1;
%I=7;
F = 10*ones(I-1,I-1); % RHS

% grid for plotting
s1=linspace(0,1,I-1);
s2=linspace(0,1,I-1);
[S1,S2]= meshgrid(s1,s2);

% parameters of covariance matrix for gaussian random field
% we work directly in KL expansion
tau_ini = 0.01;
alpha = 2;
meanfield = 0;

I_c = 3^2; % number of coefficients
C0 = eye(I_c,I_c);


% compute KL expansion of the gaussian random field
u_kle = @(xi)kle_execute(xi,S1,S2,meanfield,alpha,tau_ini);

% we estimate coefficients of KL expansion
% set groundtruth
coef_true = mvnrnd(zeros(I_c,1),C0,1)';
utrue = u_kle(coef_true);

[u,lambda]=kle_execute_coef(coef_true,S1,S2,meanfield,alpha,tau_ini);

U = reshape(utrue,[I-1 I-1]);

% reference solution
G_solve = @(ctr) G_darcy(u_kle(ctr),I-1,F);
y_solution = G_solve(coef_true);


% Construction of Observation matrix O
Points = 1:length(y_solution);
K = 30; %amount of observation points
O = zeros(K,length(y_solution));

for i = 1:K
    obs_point = randi([1 length(Points)],1,1);
    O(i,Points(obs_point)) = 1;
    Points(obs_point) = [];
end


% define forward model
G = @(ctr) O*G_darcy(u_kle(ctr),I-1,F);

% compute noisefree observation
y = G(coef_true);

% perturb by some noise
Gamma = 0.01*eye(K,K);
y_noise = y+Gamma^(1/2)*randn(K,1);


%Apply EKI on observation points.
%Define parameters 

%d=size(utrue,1); %dimension of parameter space
d=size(coef_true,1); %dimension of parameter space
k=K; %dimension of observation space;
J=5; %ensemble size
beta=1e-2; %regularisation factor
Gamma=0.01*eye(k); %noise matrix
T=1e10; %End time
rep=1;% amount of runs we do
y=y_noise;
C_0=diag(sort(lambda(:),'descend'));
%C_0=eye(d);
%tau_adap=0.1;
a = min(coef_true)+0.8*abs(min(coef_true));
b = max(coef_true)-0.8*abs(max(coef_true));
end
% End initialization of nonlinear example
%-------------------------------------------------

%Initialization of linear example
%-------------------------------------------------
if nonlin==false
dt = 0.05; % time stepsize
T_end_heat = 0.3; % time horizon
h = 0.01; % spatial stepsize


% Random field
x = h:h:1-h; %spatial points
x_h = x; %copy of x
Lsc = 0.1; % Length scale parameter/correlation length
N_KL = 12; % Number of terms in Karhunen-Loève expansion
ExpCov = 10*exp((-abs(x-x'))/(Lsc)); % Definition of covariance matrix
[U,V] = eigs(ExpCov,N_KL); % Eigendecomposition to compute KL expansion

% Variable parameters

time_steps = T_end_heat/dt;
time_steps_copy=int32(time_steps);
N  = (1/h) -1; %(Number of discretisation points)
plot_results=0;



f_coef = U*sqrt(V)*normrnd(0,1,N_KL,1); % Forcing
u_0_pde =zeros((1/h)-1,1); % Initial condition

u_res_coef=heatequation(u_0_pde,T_end_heat,h,dt,plot_results,f_coef);
u_res_coef(1,:)=[];
u_res_coef=u_res_coef';


e=ones(N,1);
Lap_mat=(1/h^2)*spdiags([e -2*e e],-1:1,N,N);

%Construct result vector from data by stacking solution for each time step
u_res_coef=u_res_coef(:);

%Construct inverse matrix
M=((speye(N)-dt/2*Lap_mat)/dt)\eye(N);


for t=1:time_steps+1
   u_res_coef(((t-1)*N+1):(t*N))=u_res_coef(((t-1)*N+1):(t*N))-((1/2)*M*Lap_mat)^t*u_0_pde;
end

%Construct result for EKI with parameters
%y=u_res_coef;

%Construct forward operator 
A=zeros(N*time_steps_copy,N);
rec_sum=zeros(N);
for t=1:time_steps+1
    rec_sum=rec_sum+M^t*((0.5*Lap_mat)^(t-1));
    A(((t-1)*N+1):(t*N),:)=rec_sum;
end

% define forward model
G = @(utr) A*utr;
% compute noisefree observation
utrue=f_coef;

y = G(utrue);

% perturb by some noise
K=size(y,1);
Gamma = 0.01*eye(K,K);
y_noise = y+Gamma^(1/2)*randn(K,1);
%y_noise=y;


%Apply EKI on observation points.
%Define parameters 

d=size(utrue,1); %dimension of parameter space
%k=K; %dimension of observation space
J=10; %ensemble size
beta=5e-1; %regularisation factor
alpha=0;
Gamma=0.01*eye(K); %noise matrix
T=100; %End time
rep=1;% amount of runs we do
y=y_noise;
%C_0=eye(d);
C_0=ExpCov;
%tau_adap=0.1;

a = min(utrue)+0.95*abs(min(utrue));
b = max(utrue)-0.95*abs(max(utrue));
end

% End initialization of linear example
%-------------------------------------------------

%Generate Box take only one upper value and lower value



Box = [a,b];
LB = Box(1)*ones(d,1);
UB = Box(2)*ones(d,1);

%tau_pen=T;



%Determine times for ODE solver
tspan_1=0:0.02:1;
tspan_2= 1:T/100:T;
%tspan_2 = linspace(1,T)
tspan_1(end)=[];
tspan_alt=[tspan_1,tspan_2];
%tspan_alt=[0,T];
t=zeros(length(tspan_alt),rep);
opts=odeset('RelTol',1e-12,'AbsTol',1e-12);

%Variables that are used for evaluation in main script
L=length(tspan_alt);

%diff_t=log10(T)+1;
diff_t=1;
est_err_BC=zeros(length(tspan_alt),diff_t);
est_err_sol_BC=zeros(length(tspan_alt),diff_t);

est_err_BC_b=zeros(length(tspan_alt),diff_t);
est_err_sol_BC_b=zeros(length(tspan_alt),diff_t);

poten_err_eki=zeros(length(tspan_alt),diff_t);
poten_err_eki_bc=zeros(length(tspan_alt),diff_t);

poten_err_eki_b=zeros(length(tspan_alt),diff_t);
poten_err_eki_bc_b=zeros(length(tspan_alt),diff_t);


%save('EKI_Darcy_nonlin_params.mat');

if 1==0

% plotting groundtruth
figure(1)
clf(1)
surf(S1,S2,U);colorbar; 
colormap('cool');
shading interp;
view(2);
colormap Jet;
axis square

% plot pde solution and observation points
obs_points = O*[1:length(y_solution)]';
obs_vector = zeros(length(y_solution),1);
obs_vector(obs_points) = 1;
obs_plot_1 = S1(obs_vector==1);
obs_plot_2 = S2(obs_vector==1);

fig2 = figure(3);
clf(3)
set(fig2, 'Units', 'normalized', 'Position', [0.1, 0.5, 0.2, 0.2]);

[X,Y] = meshgrid(linspace(0,1,I-1),linspace(0,1,I-1));
surf(X,Y,reshape(y_solution,[I-1,I-1]));hold on
colorbar;
colormap('cool');
shading interp;
view(2);
colormap Jet;
%p1=plot3(obs_plot_1,obs_plot_2,ones(size(obs_plot_1)),'ko','LineWidth',2,'DisplayName','Observation points','markersize',2);
%title('PDE solution','FontSize',16,'Interpreter','latex')
%legend('show',p1,'Location','northeast');
axis square

end

%------------------------------------------



%Define Potentail and set options for optimisation
%We use the optimisation solution as reference solution   

%fun = @(u) (1/2)*norm((sqrtm(Gamma))\(G(u)-y))^2+(beta/2)*norm((sqrtm(C_0))\u)^2;
fun = @(u) Phi_nonlinear(u,Gamma,G,y,a,b,beta,C_0,1);
options = optimoptions(@fmincon,'MaxFunctionEvaluations',10^8,'Algorithm','sqp','MaxIterations',1000,'Display','iter','OptimalityTolerance',10^(-10));%,'StepTolerance',10^(-20));


for i=1:rep
    
% we estimate coefficients of KL expansion
% set groundtruth

%----------nonlinear----------------
coef_0 = mvnrnd(zeros(I_c,1),C0,J)';
% u_0 = u_kle(coef_0); %initial ensemble
%----------linear-------------------
%u_0 = mvnrnd(zeros(d,1),C_0,J)'; %initial ensemble

%Solve Eki with BC
u_0=coef_0;
u_1 = u_0;
epsilon=1e-2;
u_1(u_1<=Box(1)) = Box(1)+epsilon;
u_1(u_1>=Box(2)) = Box(2)-epsilon;

%Generate Basis
%u_0_bar=mean(u_0,2);
u_1_bar=mean(u_1,2);
%e_0=u_0-u_0_bar; %center particles
e_0=u_1-u_1_bar;
[R,basiccol]=rref(e_0); %determine linear independent ensembles
if J<=d
    E_0=e_0;
else
    E_0=u_1(:,basiccol);
end


%Projection onto subspace; needed for optimisation
P_E=E_0*((E_0'*E_0)\(E_0'));
u_sub_orth=u_1_bar-P_E*u_1_bar;

%Preallocation of different error values computed
est_err=zeros(length(tspan_alt),1);
est_err_sol=zeros(length(tspan_alt),diff_t);

%Preallocation of different error values computed
est_err_b=zeros(length(tspan_alt),1);
est_err_sol_b=zeros(length(tspan_alt),diff_t);

%Solve Eki
tic;
[t_long,U_long]=ode45(@(t,U) ode_right_side_nonlin(t,U,G,d,J,y,Gamma,beta,1,C_0),tspan_alt,u_1(:),opts);
U_long=reshape(U_long.',d,J,[]);
fprintf(' EKI: ')
toc;



%Solve optimisation problem
%[reg_data_missfit,fval] = fmincon(fun,mean(u_0,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options); 
%[reg_data_missfit,fval] = fmincon(fun,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,LB,UB,[],options);
%[reg_data_missfit_b,fval_b] = fmincon(fun_b,mean(end_solution_eki,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options);
%[reg_data_missfit,fval] = fmincon(fun,mean(u_1,2),[],[],[],[],LB,UB,[],options);

end_solution_eki=u_1;


for counter=1:diff_t 

tau_adap=1e3;
tic;
[t_BC,U_long_BC]=ode45(@(t,U) ode_right_side_nonlin_BC(t,U,G,d,J,y,Gamma,beta,Box,tau_adap,C_0),tspan_alt,end_solution_eki(:),opts);
U_long_BC=reshape(U_long_BC.',d,J,[]);
fprintf(' EKI with BC: ')
toc;

end_solution_eki=mean(U_long_BC(:,:,end),2);
end_solution_eki_b=mean(U_long_BC(:,:,end),2);


%fun_b = @(u) Phi_nonlinear_b(u,Gamma,G,y,a,b,beta,C_0,tau_adap);

opt_count=log10(T)+1;

%for zaehl=1:opt_count
    fun_b = @(u) Phi_nonlinear_b(u,Gamma,G,y,a,b,beta,C_0,tau_adap);
    if J<=d
        [reg_data_missfit,fval] = fmincon(fun,end_solution_eki,[],[],(eye(d)-P_E),u_sub_orth,LB,UB,[],options);
        [reg_data_missfit_b,fval_b] = fmincon(fun_b,end_solution_eki_b,[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options);
        end_solution_eki=reg_data_missfit;
        end_solution_eki_b=reg_data_missfit_b;
    else
        [reg_data_missfit,fval] = fmincon(fun,end_solution_eki,[],[],[],[],LB,UB,[],options);
        [reg_data_missfit_b,fval_b] = fminunc(fun_b,end_solution_eki_b,options);
        end_solution_eki=reg_data_missfit;
        end_solution_eki_b=reg_data_missfit_b;
    end
%        tau_adap=tau_adap*10;
%end

     for m=1:L
         %est_err(m) = (fun(mean(U_long(:,:,m),2))-fval);%/norm(fval);
         %est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);%/norm(reg_data_missfit);
         est_err_BC(m,counter) = norm(fun(mean(U_long_BC(:,:,m),2))-fval);%/norm(fval);
         est_err_sol_BC(m,counter)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit);%/norm(reg_data_missfit);
         est_err_BC_b(m,counter) = norm(fun_b(mean(U_long_BC(:,:,m),2))-fval_b);%/norm(fval_b);
         est_err_sol_BC_b(m,counter)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit_b);%/norm(reg_data_missfit_b); 
         poten_err_eki_bc(m)=fun(mean(U_long_BC(:,:,m),2));
         poten_err_eki_bc_b(m)=fun_b(mean(U_long_BC(:,:,m),2));
     end


end
 
%test=reg_data_missfit;
%Save results
%parsave(sprintf('NumericsNonLin/output%d.mat', i), U_long, U_long_BC, reg_data_missfit,fval);


end

%Load results and compute error values
%parload(sprintf('NumericsNonLin/output%d.mat', i), U_long, U_single_sub);
%load(sprintf('NumericsNonLin/output%d.mat', i));
%U_long=x;
%U_long_BC=y;
%reg_data_missfit=z;
%fval=v;
     for m=1:L
         est_err(m) = norm(fun(mean(U_long(:,:,m),2))-fval);%/norm(fval);
         est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);%/norm(reg_data_missfit);
         est_err_b(m) = norm(fun(mean(U_long(:,:,m),2))-fval_b);%/norm(fval_b);
         est_err_sol_b(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit_b);%/norm(reg_data_missfit_b);         
         %est_err_BC(m) = (fun(mean(U_long_BC(:,:,m),2))-fval);%/norm(fval);
         %est_err_sol_BC(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit);%/norm(reg_data_missfit);
         poten_err_eki(m)=fun(mean(U_long(:,:,m),2));
         poten_err_eki_b(m)=fun_b(mean(U_long(:,:,m),2));
     end



     % for m=1:L_BC
     %     %est_err(m) = (fun(mean(U_long(:,:,m),2))-fval);%/norm(fval);
     %     %est_err_sol(m)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);%/norm(reg_data_missfit);
     %     est_err_BC(m) = norm(fun(mean(U_long_BC(:,:,m),2))-fval)/norm(fval);
     %     est_err_sol_BC(m)=norm(mean(U_long_BC(:,:,m),2)-reg_data_missfit)/norm(reg_data_missfit);
     % end

%clearvars U_long U_long_BC reg_data_missfit fval x y z v

%Ensemble collapse
est_err_ek = zeros(length(tspan_alt),J);
est_err_ek_BC = zeros(length(tspan_alt),J);

%load(sprintf('NumericsNonLin/output%d.mat', i));
%U_long=x;
%U_long_BC=y;
 for m=1:L
     for j=1:J
     est_err_ek(m,j)=norm(U_long(:,j,m)-mean(U_long(:,:,m),2));
     %est_err_ek_BC(m,j)=norm(U_long_BC(:,j,m)-mean(U_long_BC(:,:,m),2));
     end
 end

  for m=1:L
     for j=1:J
     %est_err_ek(m,j)=norm(U_long(:,j,m)-mean(U_long(:,:,m),2));
     est_err_ek_BC(m,j)=norm(U_long_BC(:,j,m)-mean(U_long_BC(:,:,m),2));
     end
 end

% clearvars U_long U_long_BC x y z v

%Take the mean ensemble collapse over all runs
ek_eki=est_err_ek;
ek_eki_BC=est_err_ek_BC;

%Plot results
fig4 = figure(4);
clf(4);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err,'Color',[204 37 41]./255,'LineWidth',2)
%plot(tspan_alt,mean(est_err_BC,2),'Color',[0 0.4470 0.7410],'LineWidth',2)
plot(tspan_alt,est_err_BC,'LineWidth',2)
lgd_obs = legend({'EKI','EKI_{BC} \tau=0.1','EKI_{BC} \tau=1','EKI_{BC} \tau=10','EKI_{BC} \tau=100','EKI_{BC} \tau=1000','EKI_{BC} \tau=10000','EKI_{BC} \tau=100000'},'Location','southwest');
title(lgd_obs,'$\frac{||\Phi(\bar{u}(t))-\Phi(u_{Opt})||}{\Phi(u_{Opt})}$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Mean absolute error of functionals', 'interpreter', 'latex','FontSize',20)

fig5 = figure(5);
clf(5);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err_sol,'Color',[204 37 41]./255,'LineWidth',2.5)
%plot(tspan_alt,mean(est_err_sol_BC,2),'Color',[0 0.4470 0.7410],'LineWidth',2)
plot(tspan_alt,est_err_sol_BC,'LineWidth',2)
lgd = legend({'EKI','EKI_{BC} \tau=0.1','EKI_{BC} \tau=1','EKI_{BC} \tau=10','EKI_{BC} \tau=100','EKI_{BC} \tau=1000','EKI_{BC} \tau=10000','EKI_{BC} \tau=100000'},'Location','southwest');
title(lgd,'$\frac{||\bar{u}(t)-u_{Opt}||}{\|u_{Opt}\|}$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Mean absolute error of computed solutions','interpreter', 'latex','FontSize',20)

%Plot results
fig12 = figure(12);
clf(12);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,poten_err_eki_b,'Color','red','LineWidth',2)
plot(tspan_alt,poten_err_eki_bc_b,'Color','green','LineWidth',2)
plot(tspan_alt,ones(length(tspan_alt))*fval_b,'Color','blue','LineWidth',2)
lgd_obs = legend({'EKI','EKI_{BC}','Optimiser'},'Location','southwest');
title(lgd_obs,'$\frac{||\Phi_b(\bar{u}(t))-\Phi_b(u_{Opt})||}{\Phi_b(u_{Opt})}$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Potential error b', 'interpreter', 'latex','FontSize',20)

%Plot results
fig13 = figure(13);
clf(13);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,poten_err_eki,'Color','red','LineWidth',2)
plot(tspan_alt,poten_err_eki_bc,'Color','green','LineWidth',2)
plot(tspan_alt,ones(length(tspan_alt))*fval,'Color','blue','LineWidth',2)
lgd_obs = legend({'EKI','EKI_{BC}','Optimiser'},'Location','southwest');
title(lgd_obs,'$\frac{||\Phi_b(\bar{u}(t))-\Phi_b(u_{Opt})||}{\Phi_b(u_{Opt})}$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Potential error', 'interpreter', 'latex','FontSize',20)

%Plot results
fig14 = figure(14);
clf(14);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err_b,'Color',[204 37 41]./255,'LineWidth',2)
%plot(tspan_alt,mean(est_err_BC,2),'Color',[0 0.4470 0.7410],'LineWidth',2)
plot(tspan_alt,est_err_BC_b,'LineWidth',2)
lgd_obs = legend({'EKI','EKI_{BC} \tau=0.1','EKI_{BC} \tau=1','EKI_{BC} \tau=10','EKI_{BC} \tau=100','EKI_{BC} \tau=1000','EKI_{BC} \tau=10000','EKI_{BC} \tau=100000'},'Location','southwest');
title(lgd_obs,'$\frac{||\Phi_b(\bar{u}(t))-\Phi_b(u_{Opt})||}{\Phi_b(u_{Opt})}$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Mean absolute error of functionals', 'interpreter', 'latex','FontSize',20)

fig15 = figure(15);
clf(15)
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,est_err_sol_b,'Color',[204 37 41]./255,'LineWidth',2.5)
%plot(tspan_alt,mean(est_err_sol_BC,2),'Color',[0 0.4470 0.7410],'LineWidth',2)
plot(tspan_alt,est_err_sol_BC_b,'LineWidth',2)
lgd = legend({'EKI','EKI_{BC} \tau=0.1','EKI_{BC} \tau=1','EKI_{BC} \tau=10','EKI_{BC} \tau=100','EKI_{BC} \tau=1000','EKI_{BC} \tau=10000','EKI_{BC} \tau=100000'},'Location','southwest');
title(lgd,'$\frac{||\bar{u}(t)-u_{Opt}||}{\|u_{Opt}\|}$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Mean absolute error of computed solutions (compare to $\Phi_b$ minimiser)','interpreter', 'latex','FontSize',20)

fig6 = figure(6);
clf(6);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,ek_eki,'LineWidth',2)
xlabel('T')
%xlim([tspan_alt(1) 1e5])
title('Ensemble Collapse EKI')

fig7 = figure(7);
clf(7);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,ek_eki_BC,'LineWidth',2)
xlabel('T')
%xlim([tspan_alt(1) 1e5])
title('Ensemble Collapse EKI with BC')


if nonlin==true
I=4;
%load(sprintf('NumericsNonLin/output%d.mat', rep));
res_end_mean=mean(U_long(:,:,end),2);
res_end_mean_BC=mean(U_long_BC(:,:,end),2);

U = reshape(res_end_mean,[I-1 I-1]);
U_ref = reshape(reg_data_missfit,[I-1 I-1]);
U_ref_b =reshape(reg_data_missfit_b,[I-1 I-1]);
U_BC = reshape(res_end_mean_BC,[I-1 I-1]);

%U_ref = reshape(z,[I-1 I-1]);

% % plotting groundtruth
% figure(8)
% clf(8)
% subplot(1,3,1)
% surf(S1,S2,U_ref_b);%colorbar; 
% colormap('cool');
% shading interp;
% view(2);
% colormap Jet;
% axis square
% title('Optimiser Solution')
% 
% subplot(1,3,2)
% surf(S1,S2,U);%colorbar; 
% colormap('cool');
% shading interp;
% view(2);
% colormap Jet;
% axis square
% title('EKI')
% 
% subplot(1,3,3)
% surf(S1,S2,U_BC);%colorbar; 
% colormap('cool');
% shading interp;
% view(2);
% colormap Jet;
% axis square
% title('EKI with BC')


%Commands to save images

% file2 = sprintf('ek_eki');
% print('-depsc',file2)



if nonlin==true
%I=4;
    % set figure(1) for estimation in parameter space
fig1 = figure(1);    
clf(fig1)
set(fig1, 'Units', 'normalized', 'Position', [0.1, 0.5, 0.4, 0.4]);

% plot the true parameter„
subplot(2,2,1)
surf(reshape(coef_true,I-1,I-1),'edgecolor','none');hold on
%surf(reshape(U_ref_b,I-1,I-1),'edgecolor','none');hold on
surf(Box(1)*ones(I-1,I-1),'FaceAlpha',0.3);hold on
surf(Box(2)*ones(I-1,I-1),'FaceAlpha',0.3);
title('utruth','FontSize',15)

% set figure(2) for estimation in observation space
% plot the true observations
% fig2 = figure(2);
% clf(fig2)
% set(fig2, 'Units', 'normalized', 'Position', [0.1, 0.5, 0.4, 0.4]);
% 
% subplot(2,2,1)
% surf(reshape(y,K,K),'edgecolor','none');
% title('Observation','FontSize',15)


% plot the EnKF estimates in the parameter space
figure(1)
subplot(2,2,2);
surf(U_ref_b,'edgecolor','none');hold on
surf(Box(1)*ones(I-1,I-1),'FaceAlpha',0.3);hold on
surf(Box(2)*ones(I-1,I-1),'FaceAlpha',0.3);
title('Optimiser solution','FontSize',15)
subplot(2,2,3);
surf(U,'edgecolor','none');hold on
surf(Box(1)*ones(I-1,I-1),'FaceAlpha',0.3);hold on
surf(Box(2)*ones(I-1,I-1),'FaceAlpha',0.3);
title('EKI','FontSize',15)
subplot(2,2,4);
surf(U_BC,'edgecolor','none');hold on
surf(Box(1)*ones(I-1,I-1),'FaceAlpha',0.3);hold on
surf(Box(2)*ones(I-1,I-1),'FaceAlpha',0.3);
title('EKI with BC','FontSize',15)

% % plot the EnKF estimates in the observation space
% figure(2)
% subplot(2,2,2);
% surf(reshape(G(U_ref),K,K),'edgecolor','none');
% title('Optimiser solution','FontSize',15)
% subplot(2,2,3);
% surf(reshape(G(U),K,K),'edgecolor','none');
% title('EKI','FontSize',15)
% subplot(2,2,4);
% surf(reshape(G(U_BC),K,K),'edgecolor','none');
% title('EKI with BC','FontSize',15)

end

end
%------------------plot everything as solution--------------
if nonlin==true
% discretization of the PDE
I = 2^5+1;
%I=7;
F = 10*ones(I-1,I-1); % RHS

% grid for plotting
s1=linspace(0,1,I-1);
s2=linspace(0,1,I-1);
[S1,S2]= meshgrid(s1,s2);

% parameters of covariance matrix for gaussian random field
% we work directly in KL expansion
tau_ini = 0.01;
alpha = 2;
meanfield = 0;

I_c = 3^2; % number of coefficients
C0 = eye(I_c,I_c);

% compute KL expansion of the gaussian random field
u_kle = @(xi)kle_execute(xi,S1,S2,meanfield,alpha,tau_ini);
reg_data_missfit=u_kle(reg_data_missfit);
reg_data_missfit_b=u_kle(reg_data_missfit_b);

res_end_mean=mean(u_kle(U_long(:,:,end)),2);
res_end_mean_BC=mean(u_kle(U_long_BC(:,:,end)),2);

U = reshape(res_end_mean,[I-1 I-1]);
U_ref = reshape(reg_data_missfit,[I-1 I-1]);
U_ref_b =reshape(reg_data_missfit_b,[I-1 I-1]);
U_BC = reshape(res_end_mean_BC,[I-1 I-1]);
utrue=u_kle(coef_true);

fig27 = figure(27);    
clf(fig27)
set(fig27, 'Units', 'normalized', 'Position', [0.1, 0.5, 0.4, 0.4]);

% plot the true parameter„
subplot(2,2,1)
surf(reshape(utrue,I-1,I-1),'edgecolor','none');hold on
%surf(reshape(U_ref_b,I-1,I-1),'edgecolor','none');hold on
surf(Box(1)*ones(I-1,I-1),'FaceAlpha',0.3);hold on
surf(Box(2)*ones(I-1,I-1),'FaceAlpha',0.3);
title('utruth','FontSize',15)


% plot the EnKF estimates in the parameter space
figure(27)
subplot(2,2,2);
surf(U_ref_b,'edgecolor','none');hold on
surf(Box(1)*ones(I-1,I-1),'FaceAlpha',0.3);hold on
surf(Box(2)*ones(I-1,I-1),'FaceAlpha',0.3);
title('Optimiser solution','FontSize',15)
subplot(2,2,3);
surf(U,'edgecolor','none');hold on
surf(Box(1)*ones(I-1,I-1),'FaceAlpha',0.3);hold on
surf(Box(2)*ones(I-1,I-1),'FaceAlpha',0.3);
title('EKI','FontSize',15)
subplot(2,2,4);
surf(U_BC,'edgecolor','none');hold on
surf(Box(1)*ones(I-1,I-1),'FaceAlpha',0.3);hold on
surf(Box(2)*ones(I-1,I-1),'FaceAlpha',0.3);
title('EKI with BC','FontSize',15)
end
%---------------------end plotting the solution-----------------
%---------------------plot linear estimate----------------------
if nonlin==false

res_end_mean=mean(U_long(:,:,end),2);
res_end_mean_BC=mean(U_long_BC(:,:,end),2);

%Plot results
fig10 = figure(10);
clf(10);
hold on
grid on
plot(x,res_end_mean,'Color',[204 37 41]./255,'LineWidth',2)
plot(x,res_end_mean_BC,'Color',[0.8500 0.3250 0.0980],'LineWidth',2)
plot(x,reg_data_missfit,'Color',[0 0.4470 0.7410],'LineWidth',2)
plot(x,reg_data_missfit_b,'Color',[0.4660 0.6740 0.1880],'LineWidth',2)
plot(x,zeros(d,1)+a,'Color',[0.4940 0.1840 0.5560],'Linewidth',2)
plot(x,zeros(d,1)+b,'Color',[0.4940 0.1840 0.5560],'Linewidth',2)
plot(x,utrue,'Color',[0 0 0],'Linewidth',2)
lgd_sol=legend({'EKI','EKI_{BC}','Reference solution $\Phi$','Reference solution $\Phi_b$'},'interpreter', 'latex','Location','southwest');
title(lgd_sol,'$\frac{||\Phi(\bar{u}(t))-\Phi(u_{Opt})||}{\Phi(u_{Opt})}$','interpreter', 'latex','FontSize',20)
xlabel('T')
title('Mean absolute error of functionals', 'interpreter', 'latex','FontSize',20)


end
%Function to save in parfor loops
%function parsave(fname, x,y,z,v)
%  save(fname, 'x','y','z','v')
%end


