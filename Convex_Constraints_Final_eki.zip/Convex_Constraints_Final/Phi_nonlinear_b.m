function [ phi ] = Phi_nonlinear_b( u,Gamma,G,y,a,b,beta,C_0,tau )
    
    %z = G(w);
    %phi = norm((Gamma^(1/2))\(z(:)-y),2)^2;
    phi=(1/2)*norm((sqrtm(Gamma))\(G(u)-y))^2+(beta/2)*norm((sqrtm(C_0))\u)^2;

    %Box constraints
    a_vec=zeros(length(u),1)+a;
    b_vec=zeros(length(u),1)+b;
    loga=log(-(a_vec-u));
    logb=log(-(u-b_vec));
    phi=phi-(1/tau)*(sum(loga)+sum(logb));
    

end