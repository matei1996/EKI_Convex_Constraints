function [ phi ] = Phi_nonlinear_conv( u,Gamma,G,y,c,beta,C_0,tau )
    

    phi=(1/2)*norm((sqrtm(Gamma))\(G(u)-y))^2+(beta/2)*norm((sqrtm(C_0))\u)^2;

    %Nonlinear constraits
    penalty=log(-(0.5*norm((sqrtm(C_0))\u)^2-c));
    phi=phi-(1/tau)*penalty;

end