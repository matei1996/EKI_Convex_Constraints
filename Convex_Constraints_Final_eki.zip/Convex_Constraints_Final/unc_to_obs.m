function [ y ] = unc_to_obs( y,k )
%     y = y(:);
    I = sqrt(length(y));
%     n = I^2/k^2;
%     y = y(1:n:end);
    y = reshape(y,I,I);
    n = I/k;
    y = y(1:n:I,1:n:I);
    y = y(:);
end

