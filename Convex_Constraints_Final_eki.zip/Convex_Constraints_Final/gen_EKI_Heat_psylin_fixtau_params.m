
% Script to initalize all initial parametersfor Pseudo linear example

dt = 0.05; % time stepsize
T_end_heat = 0.05; % time horizon
h = 0.01; % spatial stepsize


% Random field
x = h:h:1-h; %spatial points
x_h = x; %copy of x
Lsc = 0.1; % Length scale parameter/correlation length
N_KL = 12; % Number of terms in Karhunen-Loève expansion
ExpCov = 10*exp((-abs(x-x'))/(Lsc)); % Definition of covariance matrix
[U,V] = eigs(ExpCov,N_KL); % Eigendecomposition to compute KL expansion

% Variable parameters

time_steps = T_end_heat/dt;
time_steps_copy=int32(time_steps);
N  = (1/h) -1; %(Number of discretisation points)
plot_results=0;

if time_steps==1
    time_steps=0;
    time_steps_copy=0;
end


f_coef = U*sqrt(V)*normrnd(0,1,N_KL,1); % Forcing
u_0_pde =zeros((1/h)-1,1); % Initial condition

u_res_coef=heatequation(u_0_pde,T_end_heat,h,dt,plot_results,f_coef);
u_res_coef(1,:)=[];
u_res_coef=u_res_coef';


e=ones(N,1);
Lap_mat=(1/h^2)*spdiags([e -2*e e],-1:1,N,N);

%Construct result vector from data by stacking solution for each time step
u_res_coef=u_res_coef(:);

%Construct inverse matrix
M=((speye(N)-dt/2*Lap_mat)/dt)\eye(N);


%for t=1:time_steps+1
for t=1:time_steps
   u_res_coef(((t-1)*N+1):(t*N))=u_res_coef(((t-1)*N+1):(t*N))-((1/2)*M*Lap_mat)^t*u_0_pde;
end

%Construct result for EKI with parameters
y=u_res_coef;

%Construct forward operator 
A=zeros(N*time_steps_copy,N);
rec_sum=zeros(N);
for t=1:time_steps+1
    rec_sum=rec_sum+M^t*((0.5*Lap_mat)^(t-1));
    A(((t-1)*N+1):(t*N),:)=rec_sum;
end



% define forward model
eps_control=1e-2; %Scaling of Nonlinear Term
G = @(utr) A*utr+eps_control*sin(utr);

% compute noisefree observation
utrue=f_coef;
y = G(utrue);

% perturb by some noise
K=size(y,1);
Gamma = 0.01*eye(K,K);
y_noise = y+Gamma^(1/2)*randn(K,1);



%Apply EKI on observation points.
%Define parameters 

d=size(utrue,1); %dimension of parameter space
J=10; %ensemble size
T=1e6; %End time
y=y_noise;
C_0=ExpCov; %Regularization Scaling Matrix
tau_adap=1e4; %Penalty Parameter

%Determine Values for nonlinearity and regularisation
A_max=max(A,[],'all');
B=norm(utrue);
beta=((4+B)*A_max+max(y))*eps_control+eps_control^2+1e-1; %regularisation factor

ubound=0.5*norm((sqrtm(C_0))\utrue); %Convex Constraint; upperbound

%Define levels of variance inflation
h_1= @(t)0.8;
h_2= @(t)1-1/(log(t+exp(1)));

%Initial Ensemble
u_0=U*sqrt(V)*normrnd(0,1,N_KL,J);


%Compute variables for subspace property
u_1=u_0;
u_1_bar=mean(u_1,2);
e_0=u_1-u_1_bar; %centered particles
[R,basiccol]=rref(e_0); %determine linear independent ensembles
if J<=d
    E_0=e_0;
else
    E_0=e_0(:,basiccol);
end

%Projection onto subspace; needed for optimisation
P_E=E_0*((E_0'*E_0)\(E_0'));
u_sub_orth=u_1_bar-P_E*u_1_bar;

end_solution_eki=u_1;

filename="EKI_Heat_psylin_fix_tau_params.mat";
save(filename);