function [ d ] = dist( x,B )
    I1 = (x<B(1));
    I2 = (x>B(2));
    d1 = abs(x(I1)-B(1));
    d2 = abs(x(I2)-B(2));
    %d = zeros(length(x),1);
    d=zeros(size(x));
    d(I1) = d1;
    d(I2) = d2;
    d=d(:);
end

