function dUdt=ode_right_side(t,U,G,d,J,y,Gamma,alpha,beta,E_0,Box,tau)

%Reshape into matrix form
U=reshape(U,[d,J]);
Y=repmat(y,1,J);

%Compute Covariance matrix
bar_u=mean(U,2);
C_u=(1/(J-1))*(U-bar_u)*(U-bar_u)';

Gu=G*U;

%RHS of ODE
dUdt=tau*(C_u+alpha/(1+t)*eye(d))*(G'*(Gamma\(Y-Gu))-beta*(E_0'*E_0)*U);

%Penalty Term
penalty=-1./(Box(1)-bar_u)+1./(bar_u-Box(2));
dUdt=dUdt+C_u*penalty;

% Iterative formula
% dUdt=zeros(d,J);
% 
% for j=1:J
%     dUdt(:,j)=(alpha*eye(d)+C_u)*(N_sub*G.'*((Gamma)\(y-G*U(:,j)))-beta*(E_0'*E_0)*U(:,j));
% end

%Reshape matrix into vector form
dUdt=dUdt(:);
end

    



