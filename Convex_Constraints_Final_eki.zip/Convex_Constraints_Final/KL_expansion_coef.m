function [res,lambda] = KL_expansion_coef(Z1,Z2,y,meanfield,tau,alpha)
    
    res = meanfield*ones(size(Z1));
    [K1,K2] = meshgrid(1:size(y,2),1:size(y,2));
    lambda = (pi^2*(K1.^2+K2.^2)+tau^2).^(-alpha/2);
    L = y.*lambda;
    for i = 1:size(Z1,1)
        for j= 1:size(Z1,2)
            cos_transform = cos(pi*(Z1(i,j) * K1 + Z2(i,j) * K2));
            res(i,j) = res(i,j)+sum(sum(L.*cos_transform));
        end
    end
end
