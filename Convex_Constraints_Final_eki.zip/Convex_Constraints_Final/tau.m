function [ t ] = tau( s )
    t = (1.-s);
    t(s<0) = 1;
    t(s>1) = 0;
end

